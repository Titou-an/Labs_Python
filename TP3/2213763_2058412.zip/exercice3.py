__version__ = "TP3 - Exercice #3"
__author__ = "William Morin (2213763), Théo Manach (2058412)"

"""
Écrire un programme python qui prend, comme entrée, un mot ou une phrase mélangée tel qu'un
caractère sur deux fait partie d'un mot (ou d'une phrase) quelconque, tandis que l'autre moitié des
caractères fait partie d'un mot (ou d'une phrase) distincte. Votre but est de démêler cette série de
caractères en deux mots distincts (ou de deux phrases distinctes) et de l'imprimer à l'écran. Par
exemple, pour le mot « aclhlaot » le code doit afficher les mots « allo » et « chat ».
Il est à noter que, pour cet exercice, les espaces sont considérées comme des caractères
et que les mots (ou phrases) doivent être de même longueur.
========================================= Exemple =========================================
$ python3 exercice3.py
Veuillez entrer un texte : aclhlaot
Votre mot 1 est : "allo"
Votre mot 2 est : "chat"
"""

# TODO : Ajouter votre code
text = input("Veuillez entrer un texte :")

mot1 = ""
mot2 = ""

for pos in range(len(text)):
    if pos % 2 == 0:
        mot1 += text[pos]
    else:
        mot2 += text[pos]

print("Votre mot 1 est :", "\"" + mot1 + "\"")
print("Votre mot 2 est :", "\"" + mot2 + "\"")

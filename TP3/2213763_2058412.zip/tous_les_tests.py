from utils_ne_pas_supprimer import run_test

import exercice1_tests
import exercice2_tests
import exercice3_tests
import exercice4_tests
import exercice5_tests

if __name__ == "__main__":
    run_test()

from utils_ne_pas_supprimer import run_test
import test_exercice1
import test_exercice2
import test_exercice3
import test_exercice4
import test_exercice5
import test_exercice6
import test_exercice7
import test_exercice8
import test_exercice9

if __name__ == "__main__":
    run_test()